Project Name: Smart Irrigation

Team Members:
1. Nishanth (120050064)
2. Dheeraj (120050061)
3. Nikhil (120050070)
4. Mahindar (120050070)

Project Description:

The aim of our project is to minimize the usage of water.
Currently in many of the smart irrigation farms
water to the plants are controlled based on
timers. This may lead to unnecessary wastage
of water. We use the factors like soil moisture,
temperature and water level to determine the
requirement for the need of water by the plant

2016 - CS308  Group 15 : Project README TEMPLATE 
================================================ 
 
Group Info: 
------------ 
+ Nishanth (120050064)
+ Dheeraj (120050061)
+ Nikhil (120050070)
+ Mahindar (120050070)
 
Extension Of NONE
------------ 
 
Have you extended your project from any other past porjects? Please mention the title here.  
NO
 
Project Description 
------------------- 
 
The aim of our project is to minimize the usage of water.
Currently in many of the smart irrigation farms
water to the plants are controlled based on
timers. This may lead to unnecessary wastage
of water. We use the factors like soil moisture,
temperature and water level to determine the
requirement for the need of water by the plant
 
  
 
Technologies Used 
------------------- 
 
Remove the items that do no apply to your project and keep the remaining ones. 
 
+   Embedded C 
+   Specialized Hardware 
 
Installation Instructions 
========================= 
   
[Energia] http://energia.nu/
 
 
Demonstration Video 
=========================  
Add the youtube link of the screencast of your project demo.
Screencast - https://youtu.be/mttodZ9dpPI
Demo video - https://youtu.be/Fx9Pj5_0soI

References 
=========== 
 
Please give references to importance resources.  
 
+ [Energia] http://energia.nu/
+ [cc3100 wifi booster] http://www.ti.com/tool/cc3100boost
+ [TIVA pin mapping] http://energia.nu/wordpress/wp-content/uploads/2014/01/LaunchPads-LM4F-TM4C-%E2%80%94-Pins-Maps-11-32.jpeg


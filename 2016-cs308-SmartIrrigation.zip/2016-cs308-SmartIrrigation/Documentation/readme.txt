Place the presentaion and report in their respective folder.
